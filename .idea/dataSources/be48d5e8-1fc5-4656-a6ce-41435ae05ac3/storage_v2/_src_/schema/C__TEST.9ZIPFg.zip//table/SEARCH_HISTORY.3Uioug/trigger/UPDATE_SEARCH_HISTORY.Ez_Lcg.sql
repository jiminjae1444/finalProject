create trigger UPDATE_SEARCH_HISTORY
    before update
    on SEARCH_HISTORY
    for each row
begin
    -- 'update_date' 컬럼을 수정할 때마다 현재 시간으로 갱신
    :new.update_date := current_date;
end;
/

